package com.thinkboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThinkboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
