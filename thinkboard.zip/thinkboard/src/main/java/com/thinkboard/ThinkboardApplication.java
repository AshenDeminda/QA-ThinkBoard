package com.thinkboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThinkboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThinkboardApplication.class, args);
	}

}
